package org.nfjs.jpractice.main;

import java.net.ConnectException;

public class ExceptionTestMain {

	public static void main(String[] args) {
		try {
			System.out.println("try\n");
			throw new java.net.ConnectException();
		} catch (ConnectException c) {
			System.out.println("catch - before e");
			String value = null;
			System.out.println(value.toUpperCase());// induce null pointer exception
			//throw new java.net.ConnectException();
		} finally {
			System.out.println("finally");
		}

	}

}
