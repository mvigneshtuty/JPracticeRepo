package org.nfjs.jpractice.main;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.Certificate;
import java.security.cert.CertificateException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Enumeration;
import java.util.Locale;

public class JCertificateReaderAppMain {

	public static void main(String[] args) {

		try {
			FileInputStream fis = new FileInputStream(
					"D:\\353453\\works\\certif_expiry_notification\\FTWsGatewayTrustStore.jks");
			KeyStore keystore = KeyStore.getInstance(KeyStore.getDefaultType());
			keystore.load(fis, "paiadmin".toCharArray());
			Enumeration<String> keystoreEnum = keystore.aliases();
			while (keystoreEnum.hasMoreElements()) {
				String alias = (String) keystoreEnum.nextElement();
				System.out.println(alias);
				Certificate cert = keystore.getCertificate(alias);
				// System.out.println(cert.toString());
				if (cert.toString().contains("Validity: [")) {
					System.out.println(cert.toString().indexOf("Validity: ["));
					String split[] = cert.toString().split("Validity:")[1].split("To:");
					String toDateStr = split[1].substring(0, split[1].indexOf("]")).trim();
					System.out.println(toDateStr);
					Date expiryDate = convertToDate(toDateStr);
					System.out.println("In date : " + expiryDate);
					int daysToExpire = calcDayDiff(expiryDate);
					System.out.println(daysToExpire);
					
				}
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (KeyStoreException e) {
			e.printStackTrace();
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		} catch (CertificateException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}


	public static Date convertToDate(String strDate) throws ParseException {
		// Sat May 04 07:08:48 IST 2019
		DateFormat dateFormat = new SimpleDateFormat("E MMM dd HH:mm:ss z yyyy", Locale.ENGLISH);
		Date dt = dateFormat.parse(strDate);

		return dt;
	}

	public static int calcDayDiff(Date expiryDate) throws ParseException {
		long diff = System.currentTimeMillis() - expiryDate.getTime();
		return (int) diff / (24 * 60 * 60 * 1000);
	}

}
