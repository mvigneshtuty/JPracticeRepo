package org.nfjs.jpractice.main;

public class SwitchCaseMain {

	public static void main(String... args) {
		int i = 10;
		doSwitch(i);
	}

	public static void doSwitch(int i) {
		switch (i) {
		case 10:
			System.out.println("Integer " + i);
			//break;
		/*default:
			System.out.println("default switch...");
			break;*/
		}
	}
}
