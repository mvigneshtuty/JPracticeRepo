package org.nfjs.jpractice.main;

import java.util.Arrays;

import org.nfjs.jpractice.domain.Movie;

public class JComparableAppMain {

	public static void main(String[] args) {
		Movie m1 = new Movie();
		m1.setMovieName("Garfield_2");
		m1.setRating(8);
		Movie m2 = new Movie();
		m2.setMovieName("Jurassic");
		m2.setRating(9);
		Movie m3 = new Movie();
		m3.setMovieName("Rio");
		m3.setRating(6);
		Movie[] movieArr = { m1, m2, m3 };
		Arrays.sort(movieArr);
		for (Movie m : movieArr) {
			System.out.println("Movie :: " + m.getMovieName() + "\t; Rating :: " + m.getRating());
		}
	}

}
