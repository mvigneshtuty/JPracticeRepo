package org.nfjs.jpractice.main;

import java.util.Arrays;

import org.nfjs.jpractice.core.StudentAgeComparator;
import org.nfjs.jpractice.core.StudentGradeComparator;
import org.nfjs.jpractice.domain.Student;

public class JComparatorAppMain {

	public static void main(String[] args) {
		Student s1 = new Student("Alan", 25, "science", "B");
		Student s2 = new Student("Ben", 22, "science", "A");
		Student s3 = new Student("Sam", 23, "science", "C");
		Student s4 = new Student("Vicky", 24, "science", "A");
		Student[] studentArr = { s1, s2, s3, s4 };
		System.out.println("With out sorting");
		System.out.println("----------------");
		for (Student s : studentArr) {
			System.out.println("Name : " + s.getName() + " :: Grade : " + s.getGrade() + " :: Age : " + s.getAge());
		}
		System.out.println("-------------");
		System.out.println("Sort by Grade");
		System.out.println("-------------");
		// Sort by Grade
		Arrays.sort(studentArr, new StudentGradeComparator());
		for (Student s : studentArr) {
			System.out.println("Name : " + s.getName() + " :: Grade : " + s.getGrade() + " :: Age : " + s.getAge());
		}
		System.out.println("------------");
		System.out.println("Sort by Age");
		System.out.println("------------");
		// Sort by Age
		Arrays.sort(studentArr, new StudentAgeComparator());
		for (Student s : studentArr) {
			System.out.println("Name : " + s.getName() + " :: Grade : " + s.getGrade() + " :: Age : " + s.getAge());
		}
		
	}

}
