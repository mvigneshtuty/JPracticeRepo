package org.nfjs.jpractice.main;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;

import org.nfjs.jpractice.domain.Student;

public class StudentsGroup {
	ArrayList<Student> studentsList;
	{
		Student s1 = new Student("Alan", 25, "science", "B");
		Student s2 = new Student("Ben", 22, "science", "A");
		Student s3 = new Student("Sam", 23, "science", "C");
		Student s4 = new Student("Vicky", 24, "science", "A");
		this.studentsList.add(s1);
		this.studentsList.add(s2);
		this.studentsList.add(s3);
		this.studentsList.add(s4);
	}

	public void sort(Comparator<Student> c) {
		Collections.sort(studentsList, c);
	}
}
