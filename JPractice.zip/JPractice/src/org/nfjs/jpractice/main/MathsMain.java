package org.nfjs.jpractice.main;

public class MathsMain {

	public static void main(String[] args) {
		

	}

}
