package org.nfjs.jpractice.main;

import java.util.Arrays;
import java.util.List;

public class VarArgs {

	public static void main(String... args) {
		args = new String[] { "argumentOne" };
		System.out.println(args.length);
		printIntArgs(new int[] { 1, 2, 3 });
	}

	public static void printIntArgs(int... intArgs) {
		System.out.println(intArgs);
	}

}
