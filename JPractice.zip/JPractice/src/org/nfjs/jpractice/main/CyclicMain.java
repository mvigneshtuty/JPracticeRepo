package org.nfjs.jpractice.main;

import org.nfjs.jpractice.domain.CyclicImpl;
import org.nfjs.jpractice.interfaces.CyclicInterface;

public class CyclicMain {

	public static void main(String[] args) {
		CyclicInterface ci = new CyclicImpl();
		System.out.println(CyclicInterface.getAverage());
		System.out.println(ci.getResult());
		/*System.out.println(ci.);*/
		

	}
	
	

}
