package org.nfjs.jpractice.main;

import org.nfjs.jpractice.core.Stack;

public class StackMain {

	public static void main(String[] args) {
		Stack s = new Stack();
		s.push("Kavin");
		s.push("Remove");
		s.push("Ryan");
		s.push("Kalai");
		System.out.println(s.popAllMatches("R"));
	}

}
