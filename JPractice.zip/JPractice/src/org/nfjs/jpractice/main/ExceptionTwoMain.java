package org.nfjs.jpractice.main;

public class ExceptionTwoMain {

	public static void main(String[] args) {

		System.out.println(isHappy());

	}

	public static boolean isHappy() {
		boolean happy;
		try {
			System.out.println("try");
			happy = true;
			return happy;
		} catch (Exception e) {
			System.out.println("catch");
			happy = false;
			return happy;
		} finally {
			System.out.println("finally");
			happy = false;
		//	return happy;
		}
	}

}
