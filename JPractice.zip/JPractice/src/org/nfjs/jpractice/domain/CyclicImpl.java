package org.nfjs.jpractice.domain;

import org.nfjs.jpractice.interfaces.CyclicInterface;

public class CyclicImpl implements CyclicInterface {

	@Override
	public int doCalc() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void calcExpense() {
		// TODO Auto-generated method stub
		
	}
	
	public int getResult(){
		return 100;
	}
	
	static int getAverage(){
		return 90;
	}

	/*@Override
	public void calcExpense() {
		// TODO Auto-generated method stub

	}*/

}
