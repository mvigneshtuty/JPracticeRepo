package org.nfjs.jpractice.domain;

/*
 * The following declaration will throw compile time error
 * 
 * public class Test extends Test{
	private String id;
}*/

public class Test {
	private String id;
}
