/**
 * 
 */
package org.nfjs.jpractice.domain;

/**
 * @author 353453
 * 
 *         domain class Movie which implements comparable interface
 *
 */
public class Movie implements Comparable<Movie> {
	private String movieName;
	private int rating;

	public String getMovieName() {
		return movieName;
	}

	public void setMovieName(String movieName) {
		this.movieName = movieName;
	}

	public int getRating() {
		return rating;
	}

	public void setRating(int rating) {
		this.rating = rating;
	}

	@Override
	public int compareTo(Movie o) {
		return o.rating - this.rating;
	}

}
