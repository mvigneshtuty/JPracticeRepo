package org.nfjs.jpractice.domain;

public class Student {
	private String name;
	private int age;
	private String lesson;
	private String grade;

	/**
	 * Student constructor
	 */
	public Student() {
		super();
	}

	/**
	 * @param name
	 * @param age
	 * @param lesson
	 * @param grade
	 */
	public Student(String name, int age, String lesson, String grade) {
		super();
		this.name = name;
		this.age = age;
		this.lesson = lesson;
		this.grade = grade;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getLesson() {
		return lesson;
	}

	public void setLesson(String lesson) {
		this.lesson = lesson;
	}

	public String getGrade() {
		return grade;
	}

	public void setGrade(String grade) {
		this.grade = grade;
	}

}
