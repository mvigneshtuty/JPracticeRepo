package org.nfjs.jpractice.play;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class StripFileContents {

	public static void main(String[] args) {
		BufferedReader  br = null;
		String currentLine;
		String splitTokenLine;
		try {
			br = new BufferedReader(new FileReader("D://353453//works//PAI_PCD//CMD//onlystations.xml"));
			while((currentLine = br.readLine())!= null){
				splitTokenLine = currentLine.substring(15);
				
				System.out.println(splitTokenLine.substring(0, splitTokenLine.indexOf("\"")));
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
