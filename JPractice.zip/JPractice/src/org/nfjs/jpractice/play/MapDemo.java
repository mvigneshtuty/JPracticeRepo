package org.nfjs.jpractice.play;

import java.util.HashMap;

public class MapDemo {
	HashMap<String, String> hMap = new HashMap<String, String>();

	public HashMap<String,String> fillMapAndSend() {
		hMap.put("k1", null);
		hMap.put("k2", "Hello!");
		return hMap;
	}

}
