package org.nfjs.jpractice.play;

import static org.junit.Assert.assertNotNull;

import org.junit.Test;

public class MapDemoTest {

	@Test
	public void inspectMap(){
		MapDemo md = new MapDemo();
		System.out.println(md.fillMapAndSend().get("k2"));
		System.out.println(md.fillMapAndSend().size());
		assertNotNull(md.fillMapAndSend().get("k1"));
	}
}
