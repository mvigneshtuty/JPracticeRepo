package org.nfjs.jpractice.core.cmd.miles;

import java.util.HashMap;
import java.util.List;

public class MilesCalculationMain {

	public static void main(String[] args) {
		args[0] = "OAG";
		// read station latitude-longitude data
		if (args.length != 1) {
			System.out.println("Invalid number of arguments; Allowed argument length :: 1 ::");
			return;
		}
		String oag_data_location = "D:\\353453\\works\\PAI_PCD\\CMD_calcMiles\\OAG\\";
		String ino_data_location = "D:\\353453\\works\\PAI_PCD\\CMD_calcMiles\\INNOVATA\\";
		String od_data_location = "D:\\353453\\works\\PAI_PCD\\CMD_calcMiles\\OD_PAIRS\\";
		String data_file = null;
		if (args[0] == "OAG") {
			data_file = oag_data_location + "OAG_DATA.txt";
		} else if (args[0] == "INO") {
			data_file = ino_data_location + "INO_DATA.txt";
		} else {
			System.out.println("Invalid station data; Allowed values ::OAG, INO ::");
			return;
		}
		String od_file = od_data_location + "OD_DATA.txt";
		HashMap<String, Station> stationHash = MilesCalcUtils.readStationData(data_file);
		List<OriginDestinationPair> odPairList = MilesCalcUtils.readODPairs(od_file);
		//String milesInfo = null;
		odPairList.forEach(p -> {
			String milesInfo = MilesCalcUtils.calcMiles(stationHash.get(p.getOrigin()), stationHash.get(p.getDestination()),
					args[0]);
			System.out.println(milesInfo);
		});
		/*for (OriginDestinationPair od : odPairList) {
			milesInfo = MilesCalcUtils.calcMiles(stationHash.get(od.getOrigin()), stationHash.get(od.getDestination()),
					args[0]);
			System.out.println(milesInfo);
		}*/

	}

}
