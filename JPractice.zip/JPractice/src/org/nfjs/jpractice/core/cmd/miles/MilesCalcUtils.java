package org.nfjs.jpractice.core.cmd.miles;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class MilesCalcUtils {

	public static HashMap<String, Station> readStationData(String data_file) {
		BufferedReader br = null;
		String dataTokens[];
		Station station;
		HashMap<String, Station> stationHash = new HashMap<String, Station>();
		try {
			String currentLine;
			br = new BufferedReader(new FileReader(data_file));
			while ((currentLine = br.readLine()) != null) {
				System.out.println(currentLine);
				dataTokens = currentLine.split(";");
				station = new Station();
				station.setStationCode(dataTokens[0]);
				station.setLatitude(Double.parseDouble(dataTokens[1]));
				station.setLatitudeDirection(dataTokens[2]);
				station.setLongitude(Double.parseDouble(dataTokens[3]));
				station.setLongitudeDirection(dataTokens[4]);
				stationHash.put(station.getStationCode(), station);
			}
		} catch (IOException ioe) {
			ioe.printStackTrace();
		} finally {
			try {
				if (br != null)
					br.close();
			} catch (IOException ioe) {
				ioe.printStackTrace();
			}
		}
		return stationHash;
	}

	public static List<OriginDestinationPair> readODPairs(String od_file) {
		BufferedReader br = null;
		String dataTokens[];
		OriginDestinationPair odPair;
		List<OriginDestinationPair> odPairList = new ArrayList<OriginDestinationPair>();
		try {
			String currentLine;
			br = new BufferedReader(new FileReader(od_file));
			while ((currentLine = br.readLine()) != null) {
				dataTokens = currentLine.split(";");
				odPair = new OriginDestinationPair();
				odPair.setOrigin(dataTokens[0]);
				odPair.setDestination(dataTokens[1]);
				odPairList.add(odPair);
			}
		} catch (IOException ioe) {
			ioe.printStackTrace();
		} finally {
			try {
				if (br != null)
					br.close();
			} catch (IOException ioe) {
				ioe.printStackTrace();
			}
		}
		return odPairList;
	}

	public static String calcMiles(Station origin, Station destination, String stationSource) {

		final double C_PI = 3.14159265358979;
		double DstHorz;
		double AngSin;
		double SAng;
		// using java inbuilt methods:
		double ori_lat = Math.toRadians(origin.getLatitude());
		String ori_lat_ck = origin.getLatitudeDirection();
		double ori_long = Math.toRadians(origin.getLongitude());
		String ori_long_ck = origin.getLongitudeDirection();
		double dest_lat = Math.toRadians(destination.getLatitude());
		String dest_lat_ck = destination.getLatitudeDirection();
		double dest_long = Math.toRadians(destination.getLongitude());
		String dest_long_ck = destination.getLongitudeDirection();
		double calculateAirportDistance;

		// revising values based on direction:
		ori_lat = (ori_lat_ck == "S") ? ori_lat * -1 : ori_lat;
		dest_lat = (dest_lat_ck == "S") ? dest_lat * -1 : dest_lat;
		ori_long = (ori_long_ck == "E") ? ori_long : ori_long * -1;
		dest_long = (dest_long_ck == "E") ? dest_long : dest_long * -1;

		DstHorz = Math.abs(ori_long - (dest_long));
		if (DstHorz > C_PI) {
			DstHorz = (2 * C_PI) - DstHorz;
		}

		// formula : AngSin = Cos((C_PI / 2) - ori_lat) * Cos((C_PI / 2) -
		// dest_lat) + Sin((C_PI / 2) - ori_lat) * Sin((C_PI / 2) - dest_lat) *
		// Cos(DstHorz)
		AngSin = Math.cos((C_PI / 2) - ori_lat) * Math.cos((C_PI / 2) - dest_lat)
				+ Math.sin((C_PI / 2) - ori_lat) * Math.sin((C_PI / 2) - dest_lat) * Math.cos(DstHorz);
		// formula : SAng = Atn(Sqr(1 - (AngSin * AngSin)) / AngSin)
		SAng = Math.atan(Math.sqrt(1 - (AngSin * AngSin)) / AngSin);
		if (SAng < 0) {
			SAng = SAng + C_PI;
		}
		// formula : calculateAirportDistance = Round(((SAng * 69 * 180) /
		// C_PI), 0)

		calculateAirportDistance = Math.rint(((SAng * 69 * 180) / C_PI));
		// System.out.println("calculateAirportDistance : " +
		// calculateAirportDistance);
		return "Origin : " + origin.getStationCode() + " ; Destination : " + destination.getStationCode()
				+ " ; Miles : " + calculateAirportDistance + " ; DataType : " + stationSource;

	}
}
