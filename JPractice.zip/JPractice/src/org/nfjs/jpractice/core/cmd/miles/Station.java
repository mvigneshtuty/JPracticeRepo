package org.nfjs.jpractice.core.cmd.miles;

public class Station {
	private String stationCode;
	private double latitude;
	private String latitudeDirection;
	private double longitude;
	private String longitudeDirection;

	public String getStationCode() {
		return stationCode;
	}

	public void setStationCode(String stationCode) {
		this.stationCode = stationCode;
	}

	public double getLatitude() {
		return latitude;
	}

	public void setLatitude(double latitude) {
		this.latitude = latitude;
	}

	public String getLatitudeDirection() {
		return latitudeDirection;
	}

	public void setLatitudeDirection(String latitudeDirection) {
		this.latitudeDirection = latitudeDirection;
	}

	public double getLongitude() {
		return longitude;
	}

	public void setLongitude(double longitude) {
		this.longitude = longitude;
	}

	public String getLongitudeDirection() {
		return longitudeDirection;
	}

	public void setLongitudeDirection(String longitudeDirection) {
		this.longitudeDirection = longitudeDirection;
	}

}
