package org.nfjs.jpractice.core.concurrency;

import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

public class UsingExecutor {
	public static void main(String args[]) {
		final Executor executor = Executors.newCachedThreadPool();
		executor.execute(new HelperThread());
		executor.execute(new HelperThread());
		executor.execute(new HelperThread());
	}
}