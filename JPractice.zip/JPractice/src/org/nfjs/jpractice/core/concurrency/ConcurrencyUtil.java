package org.nfjs.jpractice.core.concurrency;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.TimeUnit;

public class ConcurrencyUtil {

	public static void shutdown(ExecutorService es, long terminationWaitPeriod) {

		try {
			es.shutdown();
			es.awaitTermination(terminationWaitPeriod, TimeUnit.SECONDS);
		} catch (InterruptedException e) {
			System.err.println("Task termination wait interrupted.");
		} finally {
			if (!es.isTerminated()) {
				System.err.println("Killing non-finished tasks.");
				es.shutdownNow();
			}
		}
	}
}
