package org.nfjs.jpractice.core.concurrency.synchronization;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.locks.ReentrantLock;
import java.util.stream.IntStream;

import org.nfjs.jpractice.core.concurrency.ConcurrencyUtil;

public class ExplicitReentrantLock {

	private static final int INCREMENT_LIMIT = 10000;
	private static int count;
	private static ReentrantLock lock = new ReentrantLock();

	public static void main(String[] args) {
		doNonSyncCount();
		doLockCount();
	}

	private static void doNonSyncCount() {
		count = 0;
		ExecutorService executor = Executors.newFixedThreadPool(2);
		IntStream.range(0, INCREMENT_LIMIT).forEach(p -> {
			executor.submit(ExplicitReentrantLock::incrementCount);
		});
		ConcurrencyUtil.shutdown(executor, 10);
		System.out.println("No lock count :: " + count);
	}

	private static void doLockCount() {
		count = 0;
		ExecutorService executor = Executors.newFixedThreadPool(2);
		IntStream.range(0, INCREMENT_LIMIT).forEach(p -> {
			executor.submit(ExplicitReentrantLock::lockIncrementCount);
		});
		ConcurrencyUtil.shutdown(executor, 10);
		System.out.println("Lock count :: " + count);
	}

	public static void incrementCount() {
		count++;
	}

	public static void lockIncrementCount() {
		lock.lock();
		try {
			count++;
		} finally {
			if (lock.isLocked())
				lock.unlock();
		}
	}

}
