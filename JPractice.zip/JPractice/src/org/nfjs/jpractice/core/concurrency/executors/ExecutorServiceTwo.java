package org.nfjs.jpractice.core.concurrency.executors;

import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

public class ExecutorServiceTwo {

	public static void main(String[] args) {
		initFutureExecution();
	}

	public static void initFutureExecution() {
		ExecutorService esInit = Executors.newSingleThreadExecutor();
		Future<String> f = esInit.submit(() -> {
			TimeUnit.SECONDS.sleep(5);
			return "Hello Future! Aspiring to become Java expert.";
		});
		try {
			stopFutureExecution(esInit,f);
			String execResult = f.get();
			
			System.out.println("Future_result :: " + execResult);
		} catch (InterruptedException | ExecutionException e) {
			System.out.println("Future Execution interrupted");
			e.printStackTrace();
		} /*catch (TimeoutException e) {
			System.out.println("Future wait complete");
			e.printStackTrace();
		}*/
		
	}

	public static void stopFutureExecution(ExecutorService esStop,Future<String> future) {
		// killing tasks after wait period;
		List<Runnable> runnableTasks = null;
		try {
			//esStop.awaitTermination(5, TimeUnit.SECONDS);
			runnableTasks = esStop.shutdownNow();
		} /*catch (InterruptedException e) {
			System.out.println("Completing shutdown");
		}*/ finally {
			System.out.println(future.isDone()?"Task done":"Task not done");
			
		}
		runnableTasks.forEach(p -> System.out.println(p.getClass()));
	}
}
