package org.nfjs.jpractice.core.concurrency.executors;

import java.util.Date;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.TimeUnit;

public class ScheduledExecutor {

	public static void main(String[] args) {
		//ScheduledFuture<?> sfuture = init(3).schedule(getTask(), 5, TimeUnit.SECONDS);
		//ScheduledFuture<?> sfuture = init(3).scheduleAtFixedRate(getTask(), 1, 5, TimeUnit.SECONDS);
		ScheduledFuture<?> sfuture = init(1).scheduleWithFixedDelay(getTask(), 1, 5, TimeUnit.SECONDS);
		System.out.println(
				sfuture.isDone() ? "Task status :: completed" : "Task status :: Incomplete; waiting to launch");
		while (sfuture.getDelay(TimeUnit.SECONDS) > 0) {
			try {
				TimeUnit.MILLISECONDS.sleep(500);
				System.out.println("Time left to launch task :: " + sfuture.getDelay(TimeUnit.SECONDS) + " second(s)");
			} catch (InterruptedException e) {
				System.out.println("Scheduled wait for task launch interrupted.");
			}
		}

		while (!sfuture.isDone()) {
			// wait for task execution to complete
		}
		System.out
				.println(sfuture.isDone() ? "Task status :: completed on " + new Date() : "Task status :: Incomplete");
		
	}

	public static ScheduledExecutorService init(int numOfThreads) {
		return Executors.newScheduledThreadPool(numOfThreads);
	}

	public static Runnable getTask() {
		return () -> {
			System.out.println("Executing scheduled task :: " + ThreadLocalRandom.current().nextInt(1, 101));
			System.out.println("Start time :: "+new Date());
			try {
				TimeUnit.SECONDS.sleep(7);
			} catch (InterruptedException e) {
				System.out.println("Task execution interrupted.");
			}
		};
	}
}
