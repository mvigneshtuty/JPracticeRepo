package org.nfjs.jpractice.core.concurrency.executors;

import java.util.Date;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

public class ExecutorServiceThree {

	public static void main(String[] args) {
		initExecution();

	}

	public static void initExecution() {
		ExecutorService es = Executors.newFixedThreadPool(1, (Runnable r) -> new Thread(r));

		Future<String> future = es.submit(() -> {
			TimeUnit.SECONDS.sleep(1);
			return "Callable Execution Result :: " + Math.random();
		});
		getResult(future, es);
		// stopExecution(es);
	}

	public static void getResult(Future<String> future, ExecutorService es) {
		System.out.print(future.isDone() ? "Future computation done\t :: " : "Future computation not done :: ");
		System.out.print(new Date() + "\n");
		String futureResult = null;
		try {
			stopExecution(es);
			futureResult = future.get(3, TimeUnit.SECONDS);
		} catch (InterruptedException | ExecutionException | TimeoutException e) {
			System.out.println("Future computation exception ");
			System.out.println(new Date());
			e.printStackTrace();
		}
		System.out.print(future.isDone() ? "Future computation done\t :: " : "Future computation not done\t :: ");
		System.out.print(new Date() + "\n");
		System.out.println(futureResult);
	}

	public static void stopExecution(ExecutorService es) {
		System.out.println("Starting orderly shutdown...");
		System.out.println(new Date());
		es.shutdown();
		try {
			es.awaitTermination(5, TimeUnit.SECONDS);
		} catch (InterruptedException e) {
			System.out.println("Executor service interrupted");
			System.out.println(new Date());
		} finally {
			if (!es.isTerminated()) {
				System.out.println("Some tasks alive. Attempting to Force shutdown");
				es.shutdownNow();
				System.out.println("Force shutdown complete");
				System.out.println(new Date());
			} else {
				System.out.println("Orderly shutdown complete");
				System.out.println(new Date());
			}
		}
	}
}
