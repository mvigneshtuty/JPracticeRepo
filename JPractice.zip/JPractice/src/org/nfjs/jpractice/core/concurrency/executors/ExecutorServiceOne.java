package org.nfjs.jpractice.core.concurrency.executors;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import org.nfjs.jpractice.core.concurrency.HelperThread;

public class ExecutorServiceOne {

	Thread t;
	public static void main(String... args) {
		ExecutorService es = initExecution(); // call to start executor service
		stopExecution(es); // call to stop executor service
	}

	public static ExecutorService initExecution() {
		ExecutorService esInit = Executors.newSingleThreadExecutor();
		esInit.submit(() -> {
			new HelperThread().work();
		});
		return esInit;
	}

	public static void stopExecution(ExecutorService esStop) {
		try {
			System.out.println("attempt to shutdown executor service");
			esStop.shutdown();
			esStop.awaitTermination(11, TimeUnit.SECONDS);
		} catch (InterruptedException intE) {
			System.out.println("termination interrupted");
			intE.printStackTrace();
		}
		finally{
			if (!esStop.isTerminated()) {
                System.err.println("killing non-finished tasks");
            }
			esStop.shutdownNow();
            System.out.println("shutdown finished");
		}
	}
}
