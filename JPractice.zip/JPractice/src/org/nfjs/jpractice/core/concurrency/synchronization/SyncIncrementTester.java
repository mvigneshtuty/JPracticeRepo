package org.nfjs.jpractice.core.concurrency.synchronization;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.stream.IntStream;

import org.nfjs.jpractice.core.concurrency.ConcurrencyUtil;

public class SyncIncrementTester {

	private static int count;
	private static final int INCREMENT_LIMIT = 10000;

	public static void main(String[] args) {
		doNonSyncIncrement();
		doSyncIncrement();

	}

	private static void doNonSyncIncrement() {
		ExecutorService executor = Executors.newFixedThreadPool(2);
		count = 0;
		IntStream.range(0, INCREMENT_LIMIT).forEach(p -> {
			executor.submit(SyncIncrementTester::nonSyncIncrement);
		});
		ConcurrencyUtil.shutdown(executor, 10);
		System.out.println("Non sync increment count :: " + count);
	}

	private static void doSyncIncrement() {
		ExecutorService executor = Executors.newFixedThreadPool(2);
		count = 0;
		IntStream.range(0, INCREMENT_LIMIT).forEach(p -> {
			executor.submit(SyncIncrementTester::syncIncrementBlock);
		});
		ConcurrencyUtil.shutdown(executor, 10);
		System.out.println("Sync increment count :: " + count);
	}
	
	private static void nonSyncIncrement() {
		count = count + 1;
	}

	private synchronized static void syncIncrement() {
		count++;
	}
	
	private static void syncIncrementBlock(){
		synchronized (SyncIncrementTester.class) {
			count++;
		}
	}
}
