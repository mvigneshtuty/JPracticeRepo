package org.nfjs.jpractice.core.concurrency;

public class HelperThread implements Runnable {

	@Override
	public void run() {
		// make the helper thread to sleep;
		work();
	}

	public void work() {
		for (int i = 0; i < 5; i++) {
			System.out.println("Helper thread : " + Thread.currentThread().getName() + " :: iteration " + (i + 1));
			try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		System.out.println("Helper thread complete");
	}

}
