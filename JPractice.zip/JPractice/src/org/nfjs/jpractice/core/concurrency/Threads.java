package org.nfjs.jpractice.core.concurrency;

public class Threads {

	public static void main(String[] args) throws InterruptedException {
		Thread helperThread = new Thread(new HelperThread());
		helperThread.start();
		// make the main thread to sleep;
		for (int i = 0; i < 5; i++) {
			System.out.println("Main thread : " + Thread.currentThread().getName()+ " :: iteration " + (i + 1));
			Thread.sleep(5000);
		}
		System.out.println("Main thread complete");
	}

}
