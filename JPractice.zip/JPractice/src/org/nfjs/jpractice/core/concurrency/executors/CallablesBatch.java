package org.nfjs.jpractice.core.concurrency.executors;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.TimeUnit;

public class CallablesBatch {

	public static void main(String[] args) {
		ExecutorService es = Executors.newWorkStealingPool(5);
		List<Callable<String>> tasksList = prepareCallables(3);
		System.out.println("Invoke All :: Return All");
		invokeAllReturnAll(es, tasksList);
		System.out.println("Invoke All :: Return Successful");
		invokeAllReturnSuccessful(es, tasksList);
	}

	public static List<Callable<String>> prepareCallables(int numOfTasks) {
		List<Callable<String>> callablesList = new ArrayList<Callable<String>>();
		for (int i = 0; i < numOfTasks; i++) {
			callablesList.add(getCallable(i, ThreadLocalRandom.current().nextInt(1, numOfTasks + 1)));
		}
		return callablesList;
	}

	public static Callable<String> getCallable(int index, int sleepSeconds) {
		System.out.println("Sleep seconds :: " + sleepSeconds + " for task " + (index + 1));
		return () -> {
			TimeUnit.SECONDS.sleep(sleepSeconds);
			return "Task :: " + (index + 1);
		};
	}

	public static void invokeAllReturnAll(ExecutorService es, List<Callable<String>> tasksList) {
		try {
			es.invokeAll(tasksList).stream().map(future -> {
				try {
					return future.get();
				} catch (Exception e) {
				}
				return null;
			}).forEach(System.out::println);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	public static void invokeAllReturnSuccessful(ExecutorService es, List<Callable<String>> tasksList) {
		try {
			System.out.println(es.invokeAny(tasksList));
		} catch (InterruptedException | ExecutionException e) {
			e.printStackTrace();
		}
	}
}
