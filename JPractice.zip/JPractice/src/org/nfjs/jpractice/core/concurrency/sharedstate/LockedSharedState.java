package org.nfjs.jpractice.core.concurrency.sharedstate;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class LockedSharedState {
	int iteration = 5;

	public static void main(String... args) {
		new LockedSharedState().start();
	}

	public void start() {
		ExecutorService es = Executors.newCachedThreadPool();
		MessageCounter mc = new MessageCounter();
		es.execute(() -> {
			while (iteration >= 0) {
				synchronized (mc) {
					mc.setCounter(200);
					if (200 == mc.getCounter()) {
						System.out.println("Executor wins In ExecutorThread");
					} else if (100 == mc.getCounter()) {
						System.out.println("Main wins In ExecutorThread");
					}
					iteration--;
				}

			}

			es.shutdown();
		});
		while (iteration >= 0) {
			synchronized (mc) {
				mc.setCounter(100);
				if (200 == mc.getCounter()) {
					System.out.println("Executor wins In MainThread");
				} else if (100 == mc.getCounter()) {
					System.out.println("Main wins In MainThread");
				}
				iteration--;
			}

		}
		es.shutdown();
	}

	// Inner class - MessageCounter
	public class MessageCounter {
		int counter;

		public int getCounter() {
			return counter;
		}

		public void setCounter(int counter) {
			this.counter = counter;
		}

	}
}
