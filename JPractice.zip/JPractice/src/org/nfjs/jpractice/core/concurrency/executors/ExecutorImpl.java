package org.nfjs.jpractice.core.concurrency.executors;

import java.util.concurrent.Executor;

import org.nfjs.jpractice.core.concurrency.HelperThread;

public class ExecutorImpl implements Executor {

	@Override
	public void execute(Runnable arg0) {
		new Thread(arg0).start();
	}

	public static void main(String... args) {
		new ExecutorImpl().execute(new HelperThread());
	}

}
