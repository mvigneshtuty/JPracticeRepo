package org.nfjs.jpractice.core.concurrency.sharedstate;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class SharedState {
	int iteration = 10;

	public static void main(String... args) {
		new SharedState().start();
	}

	public void start() {
		ExecutorService es = Executors.newCachedThreadPool();
		MessageCounter mc = new MessageCounter();
		es.execute(() -> {
			while (iteration >= 0) {
				synchronized (mc) {
					mc.setCounter(200);
					System.out.println("ExecutorThread");

					if (200 == mc.getCounter()) {
						System.out.println("E :: Executor effect identified.");
					} else if (100 == mc.getCounter()) {
						System.out.println("E :: Main thread effect identified.");
					}
				}
			}

			es.shutdown();
		});

		while (iteration >= 0) {
			synchronized (mc) {
				mc.setCounter(100);
				System.out.println("MainThread");

				if (200 == mc.getCounter()) {
					System.out.println("M :: Executor effect identified.");
				} else if (100 == mc.getCounter()) {
					System.out.println("M :: Main thread effect identified.");
				}
			}
			iteration--;
		}
		// es.shutdown();
	}

	// Inner class - MessageCounter
	public class MessageCounter {
		int counter;

		public int getCounter() {
			return counter;
		}

		public void setCounter(int counter) {
			this.counter = counter;
		}

	}
}
