package org.nfjs.jpractice.core.wrapper;

public class IntegerWrapperTest {

	Integer i;
	public static void main(String[] args) {
		// the Integer and other primitive wrapper classes are immutable.

	}

}
