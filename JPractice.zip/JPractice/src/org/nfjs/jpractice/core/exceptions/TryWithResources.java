package org.nfjs.jpractice.core.exceptions;

import java.io.BufferedReader;
import java.io.FileReader;

public class TryWithResources {

	public static void main(String... args) {
		readSourceFile("message.txt");
	}

	public static void readSourceFile(String fileName) {
		String sourceFilePath = "D:\\353453\\works\\app_resources\\sourceFile\\";
		String fileRowContent = null;
		try (BufferedReader br = new BufferedReader(new FileReader(sourceFilePath + fileName))) {
			while ((fileRowContent = br.readLine()) != null) {
				System.out.println(fileRowContent);
			}
		} catch (Exception e) {
			//System.out.println(e.getSuppressed().getClass().getDeclaringClass());
			e.printStackTrace();
		}

	}
}
