package org.nfjs.jpractice.core;

import java.util.Comparator;

import org.nfjs.jpractice.domain.Student;

public class StudentAgeComparator implements Comparator<Student> {

	@Override
	public int compare(Student o1, Student o2) {
		// in ascending order
		// return o1.getAge() - o2.getAge();

		// in descending order
		return o2.getAge() - o1.getAge();
	}

}
