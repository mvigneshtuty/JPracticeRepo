package org.nfjs.jpractice.core;

import java.util.Comparator;

import org.nfjs.jpractice.domain.Student;

public class StudentGradeComparator implements Comparator<Student> {

	@Override
	public int compare(Student o1, Student o2) {
		// in ascending order
		// return o1.getGrade().compareTo(o2.getGrade());

		// in descending order
		return o2.getGrade().compareTo(o1.getGrade());
	}

}
