package org.nfjs.jpractice.core.designpatterns.strategy;

public class ConsoleLogger implements Logger {

	@Override
	public void write(String message) {
		System.out.println("CONSOLE::" + message);

	}

}
