package org.nfjs.jpractice.core.designpatterns.singleton;

public class ThreadSafeSingleton {

	private static ThreadSafeSingleton singletonInstance;

	private ThreadSafeSingleton() {

	}

	public static synchronized ThreadSafeSingleton getSingletonInstance() {
		if (singletonInstance == null) {
			singletonInstance = new ThreadSafeSingleton();
		}
		return singletonInstance;
	}

	public static ThreadSafeSingleton getSingletonInstanceUsingDoubleLocking() {
		if (singletonInstance == null) {
			synchronized (ThreadSafeSingleton.class) {
				if (singletonInstance == null) {
					singletonInstance = new ThreadSafeSingleton();
				}
			}
		}
		return singletonInstance;
	}
}
