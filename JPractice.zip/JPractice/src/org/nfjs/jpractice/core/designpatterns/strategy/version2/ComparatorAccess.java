/*
 * Copyright - StarAlliance GmbH
 */
package org.nfjs.jpractice.core.designpatterns.strategy.version2;

import java.util.Arrays;
import java.util.Comparator;

public class ComparatorAccess {

	public static void main(String[] args) {
		Comparator<String> strLenComp = Host.STRING_LENGTH_COMPARATOR;
		String[] strArr3 = new String[] { "hyundai", "ford", "BMW", "Benz", "Honda" };
		Arrays.sort(strArr3, strLenComp);
		Arrays.asList(strArr3).forEach(p -> System.out.print(p + " , "));
	}

}
