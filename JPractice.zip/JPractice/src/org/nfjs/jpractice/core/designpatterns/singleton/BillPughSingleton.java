package org.nfjs.jpractice.core.designpatterns.singleton;

public class BillPughSingleton {

	private BillPughSingleton() {

	}

	public static BillPughSingleton getSingletonInstance() {
		return SingletonHelper.singletonInstance;
	}

	private static class SingletonHelper {
		private static final BillPughSingleton singletonInstance = new BillPughSingleton();
	}
}
