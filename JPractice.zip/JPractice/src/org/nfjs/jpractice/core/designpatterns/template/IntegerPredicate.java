package org.nfjs.jpractice.core.designpatterns.template;

public interface IntegerPredicate {
	boolean test(Integer i);
}
