package org.nfjs.jpractice.core.designpatterns.singleton;

import java.sql.Connection;

public enum EnumSingleton {
	INSTANCE;

	private EnumSingleton() {

	}

	public Connection getConnection() {
		// return the connection object
		return null;
	}

	public void doEnumGreeting() {
		System.out.println("Hello! Welcome to Enum singleton.");
	}
}
