/*
 * Copyright - StarAlliance GmbH
 */
package org.nfjs.jpractice.core.designpatterns.strategy.version2;

import java.util.Arrays;
import java.util.Comparator;

public class Host {

	private static class StrLenComp implements Comparator<String> {

		@Override
		public int compare(String o1, String o2) {

			return o1.length() - o2.length();
		}

	}

	private static class StrDescComp implements Comparator<String> {

		@Override
		public int compare(String o1, String o2) {

			return o2.compareTo(o1);
		}

	}

	public static final Comparator<String> STRING_LENGTH_COMPARATOR = new StrLenComp();
	public static final Comparator<String> STRING_DESC_COMPARATOR = new StrDescComp();

	public static void main(String[] args) {
		String[] strArr = new String[] { "tv", "mobile", "power bank", "b" };
		String[] strArr2 = new String[] { "sony", "zebronics", "onida", "lenovo" };
		String[] strArr3 = new String[] { "hyundai", "ford", "BMW", "Benz", "Honda" };
		// sort by string length
		System.out.println("Sorting by String length\n======================================");
		Arrays.sort(strArr, STRING_LENGTH_COMPARATOR);
		Arrays.asList(strArr).forEach(p -> System.out.print(p + " , "));
		// sort by string - descending order
		System.out.println("\nSorting by String - descending order\n=====================================");
		Arrays.sort(strArr2, STRING_DESC_COMPARATOR);
		Arrays.asList(strArr2).forEach(p -> System.out.print(p + " , "));
		// sort by string - case insensitive order
		System.out.println("\nSorting by String - case insensitive order\n=====================================");
		Arrays.sort(strArr3, String.CASE_INSENSITIVE_ORDER);
		Arrays.asList(strArr3).forEach(p -> System.out.print(p + " , "));
	}
}
