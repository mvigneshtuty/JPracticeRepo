package org.nfjs.jpractice.core.designpatterns.decorator;

public interface Car {
	public void assemble();
}
