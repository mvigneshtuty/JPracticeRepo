package org.nfjs.jpractice.core.designpatterns.template;

public class StackPredicate implements IntegerPredicate {

	@Override
	public boolean test(Integer i) {
		// always validate to true
		return true;
	}

}
