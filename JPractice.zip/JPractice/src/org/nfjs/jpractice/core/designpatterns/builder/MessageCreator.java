package org.nfjs.jpractice.core.designpatterns.builder;

public class MessageCreator {

	public static void main(String[] args) {
		Message messageWithPayload = MessageBuilder.withPayload("Hello Kavin").build();
		System.out.println(messageWithPayload.getPayload());
		System.out.println(messageWithPayload.getHeaders());
		Message messageWithHeaders = MessageBuilder.fromHeaders("Headers Map").build(); // having header value as null throws assertion error
		System.out.println(messageWithHeaders.getPayload());
		System.out.println(messageWithHeaders.getHeaders());
	}

}
