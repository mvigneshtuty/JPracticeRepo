package org.nfjs.jpractice.core.designpatterns.singleton;

public class EagerInitializationSingleton {

	private static final EagerInitializationSingleton singletonInstance = new EagerInitializationSingleton();

	private EagerInitializationSingleton() {
		// private constructor to avoid creation of objects to clients
	}

	public static EagerInitializationSingleton getSingletonInstance() {
		return singletonInstance;
	}
}
