package org.nfjs.jpractice.core.designpatterns.template;

import java.util.LinkedList;

public class StackTest {

	public static void main(String[] args) {
		Stack s = new Stack();
		s.initStack(10);
		s.push(48);
		s.push(56);
		System.out.println("***Even predicate > 40 ***");
		filter(s.getStack(), (p) -> p % 2 == 0 && p > 40);
		System.out.println("*** <=10 predicate***");
		filter(s.getStack(), new IntegerPredicate() {

			@Override
			public boolean test(Integer i) {
				if (i <= 10) {
					return true;
				}
				return false;
			}
		});
		System.out.println("*** Allow all predicate***");
		filter(s.getStack(), (p) -> {
			return true;
		});
	}

	public static void filter(LinkedList<Integer> stack, IntegerPredicate predicate) {
		stack.forEach(p -> {
			if (predicate.test(p)) {
				System.out.print(p + "\t");
			}
		});
		System.out.println();
	}

}
