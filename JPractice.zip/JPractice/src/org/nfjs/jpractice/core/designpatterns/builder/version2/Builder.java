package org.nfjs.jpractice.core.designpatterns.builder.version2;

public interface Builder<T> {
	public T build();
}
