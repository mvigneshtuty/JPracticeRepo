package org.nfjs.jpractice.core.designpatterns.singleton;

public class StaticBlockSingleton {

	private static StaticBlockSingleton singletonInstance;
	// private static final StaticBlockSingleton singletonInstance1;
	// private static final StaticBlockSingleton singletonInstance2;

	private StaticBlockSingleton() {
		// System.out.println("Constructor...");
	}

	// static block to initialize the singleton object

	static {
		System.out.println("static block start.");
		try{
			singletonInstance = new StaticBlockSingleton();
			// singletonInstance1 = new StaticBlockSingleton();
			// singletonInstance2 = new StaticBlockSingleton();
		}
		catch(Exception e){
			System.err.println("Exception occured during object initialization.");
		}
		
		System.out.println("static block end.");
	}

	{
		System.out.println("Pre constructor Initialization block in progress.");
	}

	public static StaticBlockSingleton getSingletonInstance() {
		return singletonInstance;
	}

	public String getGreetMessage() {
		return "Hello StaticBlockSingleton";
	}
}
