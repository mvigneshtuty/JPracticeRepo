package org.nfjs.jpractice.core.designpatterns.builder;

public class Message {
	private final int messageId;
	private final String payload;
	private final String headers;

	Message(int id, String payload, String headers) {
		this.messageId = id;
		this.payload = payload;
		this.headers = headers;
	}

	public int getMessageId() {
		return messageId;
	}

	public String getPayload() {
		return payload;
	}

	public String getHeaders() {
		return headers;
	}

}
