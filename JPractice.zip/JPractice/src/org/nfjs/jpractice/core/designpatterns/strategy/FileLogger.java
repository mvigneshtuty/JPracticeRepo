package org.nfjs.jpractice.core.designpatterns.strategy;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;

public class FileLogger implements Logger {

	@Override
	public void write(String message) {
		FileWriter fw = null;
		try {
			fw = new FileWriter(new File("D:\\353453\\works\\app_log\\design_patterns\\strategy_dp.log"));
			fw.write(message);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				fw.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

}
