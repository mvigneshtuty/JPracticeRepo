package org.nfjs.jpractice.core.designpatterns.builder.version2;

public class ComputerSpecificationBuider {

	public static void main(String[] args) {
		Computer hp = new Computer.SpecificationBuilder("Intel i5", "8GB", "1TB").keyboard("backlight")
				.includeBackBag(true).build();
		System.out.println(hp.getCpu() + ":: " + hp.getWifi() + ":: " + hp.getOsDisc());
	}

}
