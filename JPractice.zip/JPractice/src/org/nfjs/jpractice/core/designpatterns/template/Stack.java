package org.nfjs.jpractice.core.designpatterns.template;

import java.util.LinkedList;

public class Stack {
	LinkedList<Integer> stack;

	public LinkedList<Integer> getStack() {
		return stack;
	}

	Stack() {
		stack = new LinkedList<Integer>();
	}

	public void initStack(int stackSize) {
		for (int i = 0; i < stackSize; i++) {
			stack.add(i);
		}
	}

	public void push(int j) {
		this.stack.add(j);
	}

	public Integer pop() {
		return stack.remove(0);
	}

}
