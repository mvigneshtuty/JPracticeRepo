package org.nfjs.jpractice.core.designpatterns.factory;

public class FactoryTest {

	public static void main(String[] args) {
		Computer desktop = ComputerFactory.getComputer("desktop", "4GB", "500GB", "2.4GHz");
		Computer laptop = ComputerFactory.getComputer("laptop", "8GB", "1TB", "3.2GHz");
		System.out.print(desktop+"\n"+laptop);
	}

}
