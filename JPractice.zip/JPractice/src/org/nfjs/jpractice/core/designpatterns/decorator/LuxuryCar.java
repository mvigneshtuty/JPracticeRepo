package org.nfjs.jpractice.core.designpatterns.decorator;

public class LuxuryCar extends BasicCar {
	Car car;

	LuxuryCar(Car car) {
		this.car = car;
	}

	@Override
	public void assemble() {
		car.assemble();
		System.out.println("Luxury Car Assembling...");
	}
	
	
}
