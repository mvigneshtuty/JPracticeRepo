package org.nfjs.jpractice.core.designpatterns.singleton;

public class LazyInitializationSingleton {

	private static LazyInitializationSingleton singletonInstance;

	private LazyInitializationSingleton() {

	}

	public static LazyInitializationSingleton getSingletonInstance() {
		if (singletonInstance == null) {
			System.out.println("lazy instance null");
			return new LazyInitializationSingleton();
		}
		System.out.println("lazy instance NOT null");
		return singletonInstance;
	}
}
