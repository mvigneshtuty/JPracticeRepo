package org.nfjs.jpractice.core.designpatterns.builder.version2;

public class Computer {
	// mandatory
	private final String cpu;
	private final String ram;
	private final String storage;
	// optional
	private final int monitorInchSize;
	private final String keyboard;
	private final boolean backbagInclude;
	private final String wifi;
	private final String osDisc;

	public static class SpecificationBuilder implements Builder<Computer>{
		private final String cpu;
		private final String ram;
		private final String storage;
		// optional builder fields - initialized to default values
		private int monitorInchSize = 14;
		private String keyboard = "standard";
		private boolean backbagInclude = false;
		private String wifi = "N/A";
		private String osDisc = "N/A";

		SpecificationBuilder(String cpu, String ram, String storage) {
			this.cpu = cpu;
			this.ram = ram;
			this.storage = storage;
		}

		public SpecificationBuilder monitorSize(int val) {
			this.monitorInchSize = val;
			return this;
		}

		public SpecificationBuilder keyboard(String val) {
			this.keyboard = val;
			return this;
		}

		public SpecificationBuilder includeBackBag(boolean val) {
			this.backbagInclude = val;
			return this;
		}

		public SpecificationBuilder includeWifi(String val) {
			this.wifi = val;
			return this;
		}

		public SpecificationBuilder includeOsDisc(String val) {
			this.osDisc = val;
			return this;
		}
		
		public Computer build(){
			return new Computer(this);
		}
	}

	private Computer(SpecificationBuilder builder) {
		cpu = builder.cpu;
		ram = builder.ram;
		storage = builder.storage;
		monitorInchSize = builder.monitorInchSize;
		keyboard = builder.keyboard;
		backbagInclude = builder.backbagInclude;
		wifi = builder.wifi;
		osDisc = builder.osDisc;
	}

	public String getCpu() {
		return cpu;
	}

	public String getRam() {
		return ram;
	}

	public String getStorage() {
		return storage;
	}

	public int getMonitorInchSize() {
		return monitorInchSize;
	}

	public String getKeyboard() {
		return keyboard;
	}

	public boolean isBackbagInclude() {
		return backbagInclude;
	}

	public String getWifi() {
		return wifi;
	}

	public String getOsDisc() {
		return osDisc;
	}
	
	

}
