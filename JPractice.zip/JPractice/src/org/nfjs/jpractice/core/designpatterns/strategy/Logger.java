package org.nfjs.jpractice.core.designpatterns.strategy;

public interface Logger {
	void write(String message);
}
