package org.nfjs.jpractice.core.designpatterns.builder;

import static org.junit.Assert.assertNotNull;

public class MessageBuilder {
	Message message;
	private String payload = "Default.Payload";
	private String headers = "Default.Headers";
	private int messageId;

	MessageBuilder(String payload, String headers, int id) {
		this.payload = payload;
		this.headers = headers;
		this.messageId = id;
	}

	public Message getMessage() {
		return message;
	}

	public String getPayload() {
		return payload;
	}

	public String getHeaders() {
		return headers;
	}

	public int getMessageId() {
		return messageId;
	}

	public static MessageBuilder withPayload(String payload) {
		assertNotNull("Payload can not be null", payload);
		return new MessageBuilder(payload, "default headers", new Integer(0));
	}

	public static MessageBuilder fromHeaders(String headers) {
		assertNotNull("Headers can not be null", headers);
		return new MessageBuilder("default payload", headers, new Integer(0));
	}

	public Message build() {
		return new Message(this.messageId, this.payload, this.headers);
	}
}
