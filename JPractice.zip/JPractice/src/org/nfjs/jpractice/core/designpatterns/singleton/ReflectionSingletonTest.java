package org.nfjs.jpractice.core.designpatterns.singleton;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;

public class ReflectionSingletonTest {

	public static void main(String[] args) {
		EagerInitializationSingleton instanceOne = EagerInitializationSingleton.getSingletonInstance();
		EagerInitializationSingleton instanceTwo = EagerInitializationSingleton.getSingletonInstance();
		EagerInitializationSingleton instanceThree = null;
		Constructor[] constructorsArray = EagerInitializationSingleton.class.getDeclaredConstructors();
		for (Constructor constructor : constructorsArray) {
			constructor.setAccessible(true);
			try {
				instanceThree = (EagerInitializationSingleton) constructor.newInstance();
			} catch (InstantiationException | IllegalAccessException | IllegalArgumentException
					| InvocationTargetException e) {
				System.err.println("Error occured when creating instance using reflection.");
			}
		}
		System.out.println(instanceOne.hashCode());
		System.out.println(instanceTwo.hashCode());
		System.out.println(instanceThree.hashCode());
	}

}
