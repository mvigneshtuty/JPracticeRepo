package org.nfjs.jpractice.core.designpatterns.singleton;

public class SingletonTest {

	public static void main(String[] args) {
		// static block singleton
		StaticBlockSingleton staticBlockSingleton = StaticBlockSingleton.getSingletonInstance();
		System.out.println(staticBlockSingleton.getGreetMessage());
		// Lazy initialization
		LazyInitializationSingleton lazySingleton1 = LazyInitializationSingleton.getSingletonInstance();
		lazySingleton1 = LazyInitializationSingleton.getSingletonInstance();
		// Thread Safe singleton
		ThreadSafeSingleton threadSafeSingleton = ThreadSafeSingleton.getSingletonInstance();
		ThreadSafeSingleton threadSafeDoubleCheckSingleton = ThreadSafeSingleton.getSingletonInstanceUsingDoubleLocking();
		// BillPugh Singleton
		BillPughSingleton billPughSingleton = BillPughSingleton.getSingletonInstance();
		EnumSingleton enumSingleton = EnumSingleton.INSTANCE;
		enumSingleton.doEnumGreeting();
	}

}
