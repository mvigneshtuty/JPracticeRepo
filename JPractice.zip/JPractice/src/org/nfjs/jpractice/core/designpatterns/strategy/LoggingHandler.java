package org.nfjs.jpractice.core.designpatterns.strategy;

public class LoggingHandler {

	public static void main(String[] args) {
		// use console logging
		String consoleMessage = "CONSOLE: Messages to console";
		logMessages(new ConsoleLogger(), consoleMessage);
		String fileLogMessage = "INFO: Initialization of file logger completed";
		logMessages(new FileLogger(), fileLogMessage);
	}

	public static void logMessages(Logger logger, String message) {
		logger.write(message);
	}

}
