package org.nfjs.jpractice.core.designpatterns.decorator;

import java.io.BufferedOutputStream;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.util.zip.GZIPOutputStream;

public class OutputStream {
	FileOutputStream fos;
	BufferedOutputStream bos;
	ObjectOutputStream oos;
	GZIPOutputStream gos;
	java.io.OutputStream os;
}
