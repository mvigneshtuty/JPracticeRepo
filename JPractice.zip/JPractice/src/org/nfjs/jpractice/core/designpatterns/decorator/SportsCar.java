package org.nfjs.jpractice.core.designpatterns.decorator;

public class SportsCar extends BasicCar {

	Car car;

	public SportsCar(Car car) {
		this.car = car;
	}

	@Override
	public void assemble() {
		car.assemble();
		System.out.println("Sports Car Assembling...");
	}
	
}
