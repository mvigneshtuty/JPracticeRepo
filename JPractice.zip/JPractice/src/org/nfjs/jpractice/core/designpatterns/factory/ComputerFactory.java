package org.nfjs.jpractice.core.designpatterns.factory;

public class ComputerFactory {

	public static Computer getComputer(String pcType, String ram, String hdd, String cpu) {
		if (pcType.toLowerCase().equals("desktop")) {
			return getDesktop(ram, hdd, cpu);
		}
		return getLaptop(ram, hdd, cpu);
	}

	public static Computer getDesktop(String ram, String hdd, String cpu) {
		return new DesktopPC(ram, hdd, cpu);
	}

	public static Computer getLaptop(String ram, String hdd, String cpu) {
		return new LaptopPC(ram, hdd, cpu);
	}
}
