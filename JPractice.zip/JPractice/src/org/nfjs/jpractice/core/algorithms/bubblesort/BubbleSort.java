package org.nfjs.jpractice.core.algorithms.bubblesort;

import java.util.Arrays;

public class BubbleSort {

	public static void main(String[] args) {
		int[] sortedArray = doBubbleSort(new int[] { 6, 4, 9, 5 });
		System.out.println(sortedArray);
		Arrays.asList(sortedArray).forEach(p -> {
			for (int element : p) {
				System.out.print(element + "\t");
			}
		});
	}

	public static int[] doBubbleSort(int[] numbers) {
		boolean numbersSwitched;
		do {
			numbersSwitched = false;
			for (int i = 0; i < numbers.length - 1; i++) {
				if (numbers[i + 1] < numbers[i]) {
					int tmp = numbers[i + 1];
					numbers[i + 1] = numbers[i];
					numbers[i] = tmp;
					numbersSwitched = true;
				}
			}
		} while (numbersSwitched);

		return numbers;
	}
}
