package org.nfjs.jpractice.core.nested;

public class OuterClass {
	private String outboundMessage = "Hello Outer!";
	private static int outerCounter = 5;

	public class InnerClass {
		public void displayMessage() {
			System.out.println("From Inner class :: " + outboundMessage);
			System.out.println("From Inner class :: outerCounter :: "+outerCounter);
		}
	}

	public static class StaticInner {
		public void displayMessage() {
			System.out.println("From static Inner :: " + new OuterClass().outboundMessage);
			System.out.println("From static Inner :: outerCounter :: "+outerCounter);
		}
	}

	public static void main(String... strings) {
		OuterClass.StaticInner staticInnerObj = new OuterClass.StaticInner();
		staticInnerObj.displayMessage();

		OuterClass.InnerClass innerClassObj = (new OuterClass()).new InnerClass();
		innerClassObj.displayMessage();
	}
}
