package org.nfjs.jpractice.core.lambda.methodreference;

import java.util.ArrayList;
import java.util.Collection;
import java.util.function.Supplier;

public class ConstructorRefDemo {

	public static void main(String[] args) {
		ArrayList<String> srcList = new ArrayList<String>() {
			/**
			 * 
			 */
			private static final long serialVersionUID = -7938829907674985198L;

			{
				add("Kavin");
				add("Kalai");
				add("Vignesh");
			}
		};
		doTransfer(() -> srcList, ArrayList<String>::new);
	}

	public static <T, SOURCE extends Collection<T>, DEST extends Collection<T>> DEST transferElements(
			SOURCE sourceCollection, Supplier<DEST> collectionFactory) {

		DEST result = collectionFactory.get();
		for (T t : sourceCollection) {
			result.add(t);
		}
		return result;
	}

	public static void doTransfer(Supplier<ArrayList> sourceList, Supplier<ArrayList> destinationList) {
		ArrayList<String> srcList = sourceList.get();
		ArrayList<String> destList = destinationList.get();
		srcList.forEach(p -> destList.add("Hello " + p));
		destList.forEach(p -> System.out.println(p));

	}

}
