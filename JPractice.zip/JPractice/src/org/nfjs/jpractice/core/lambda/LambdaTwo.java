package org.nfjs.jpractice.core.lambda;

import org.nfjs.jpractice.interfaces.CustomLambdaInterface;

public class LambdaTwo {

	public static void main(String[] args) {
		// Runnable passed using lambda expression.
		new Thread(() -> {
			System.out.println("runnable via lambda expression!");
		}).start();

		process(new CustomLambdaInterface() {

			@Override
			public void printArgs(String s) {
				System.out.println("Hi " + s);

			}
		});

		processWithLambda((arg) -> {
			System.out.println("Hello " + arg);
		});
	}

	public static void process(CustomLambdaInterface c) {
		c.printArgs(new String("Anonymous"));
	}

	public static void processWithLambda(CustomLambdaInterface c) {
		c.printArgs(new String("Lambda"));
	}

}
