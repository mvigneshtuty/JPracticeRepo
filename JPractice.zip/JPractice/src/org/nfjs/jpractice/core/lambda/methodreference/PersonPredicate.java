package org.nfjs.jpractice.core.lambda.methodreference;

@FunctionalInterface
public interface PersonPredicate {
	int getAge(Person p);
}
