package org.nfjs.jpractice.core.lambda;

import java.awt.Button;
import java.awt.event.ActionEvent;

import org.nfjs.jpractice.interfaces.LambdaButtonListener;

public class LambdaFour {

	public static void main(String[] args) {
		Button b = new Button();
		b.addActionListener(new LambdaButtonListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub

			}

			@Override
			public void actionPerformed() {
				// TODO Auto-generated method stub

			}
		});

		// picks only the default ActionListener interface
		b.addActionListener((arg) -> {
			System.out.println("invoke of method from custom action listener");
		});

	}

}
