package org.nfjs.jpractice.core.lambda;

import java.util.Arrays;
import java.util.List;

public class LambdaEight {

	public static void main(String[] args) {
		List<Integer> idList = Arrays.asList(1, 2, 4, 5, 8, 6, 10, 12);
		idList.stream().filter(p -> p % 2 == 0 && p > 6).map(m -> m + 100).forEach(e -> System.out.println(e));
	}

}
