package org.nfjs.jpractice.core.lambda;

import org.nfjs.jpractice.interfaces.ThreadRunnable;

public class LambdaThree {

	public static void main(String[] args) {
		new Thread(new ThreadRunnable() {

			@Override
			public void run() {
				System.out.println("runnable - classic way");

			}
		}).start();

		new Thread(() -> {
			int i = 5;
			System.out.println("value is " + i);
			System.out.println("End of Lambda run");
		}).start();
	}

}
