package org.nfjs.jpractice.core.lambda;

import java.util.Arrays;
import java.util.List;

public class LambdaFive {

	public static void main(String[] args) {
		List<String> names = Arrays.asList("hello", "spring", "integration");
		names.forEach(arg -> {
			System.out.println("Greetings " + arg);
		});
		;
		names.forEach(System.out::println);
	}

}
