package org.nfjs.jpractice.core.lambda.methodreference;

import java.util.Arrays;
import java.util.Comparator;

public class MethodRefTester {

	public class PersonAgeComparator implements Comparator<Person> {

		@Override
		public int compare(Person p1, Person p2) {
			return p1.getAge() - p2.getAge();
		}

	}

	public static void main(String[] args) {
		Person p1 = new Person(25);
		Person p2 = new Person(28);
		Person p3 = new Person(1);
		Person p4 = new Person(12);
		Person[] personArr = new Person[] { p1, p2, p3, p4 };
		Person[] personArrOne = new Person[] { p1, p2, p3, p4 };
		Person[] personArrTwo = new Person[] { p1, p2, p3, p4 };
		Person[] personArrThree = new Person[] { p1, p2, p3, p4 };
		Arrays.asList(personArr).forEach((Person a) -> {
			System.out.print(a.getAge() + "\t");
		});

		System.out.println();
		Arrays.asList(personArrOne).stream().sorted(Person::compareByAge)
				.forEach((Person p) -> System.out.print(p.getAge() + "\t"));
		System.out.println();
		Arrays.asList(personArrTwo).stream().sorted((Person a, Person b) -> a.getAge() - b.getAge())
				.forEach((Person c) -> System.out.print(c.getAge() + "\t"));
		System.out.println();
		Arrays.asList(personArrThree).stream().sorted(new Person(0)::compareByAgeDescending)
				.forEach((Person p) -> System.out.print(p.getAge() + "\t"));
		System.out.println();

		String[] stringArray = { "Barbara", "James", "Mary", "John", "Patricia", "Robert", "Michael", "Linda" };
		String[] stringArrayTwo = { "Barbara", "James", "Mary", "John", "Patricia", "Robert", "Michael", "Linda" };
		Arrays.asList(stringArray).stream().sorted((String a, String b) -> b.compareToIgnoreCase(a))
				.forEach((String s) -> System.out.print(s + "\t"));
		System.out.println("\n\n"+"sort string using method reference - ascending : \n");
		Arrays.asList(stringArrayTwo).stream().sorted(String::compareToIgnoreCase).forEach((String s)->System.out.print(s+"\t"));
	}

}
