package org.nfjs.jpractice.core.lambda;

import java.util.concurrent.Callable;

public class LambdaTarget {

	static void  invoke(Runnable r) {
		r.run();
	}

	static <T> T  invoke(Callable<T> c) {
		try {
			return c.call();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	public static void main(String[] args) {
		System.out.println(invoke(()->"hello"));
	}

}
