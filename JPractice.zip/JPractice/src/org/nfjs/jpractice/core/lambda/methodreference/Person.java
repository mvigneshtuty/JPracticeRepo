package org.nfjs.jpractice.core.lambda.methodreference;

import java.time.LocalDate;

public class Person {
	String name;
	int age;
	LocalDate birthday;

	Person(int age) {
		this.age = age;
	}

	public int getAge() {
		return age;
	}

	public static int compareByAge(Person p1, Person p2) {
		return p1.getAge() - p2.getAge();
	}
	
	public  int compareByAgeDescending(Person p1, Person p2) {
		return p2.getAge() - p1.getAge();
	}
}
