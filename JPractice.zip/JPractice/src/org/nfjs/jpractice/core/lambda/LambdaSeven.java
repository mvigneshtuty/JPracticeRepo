package org.nfjs.jpractice.core.lambda;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

public class LambdaSeven {

	public static void main(String[] args) {
		List<Integer> list = Arrays.asList(5, 4, 3, 11, 5, 6, 7);
		list.forEach(n -> {
			int sq = n * n;
			System.out.println(sq);
		});

		Stream<Integer> s = list.stream().map(n -> n * n);
		System.out.println(s.max((Object n1, Object n2) -> (Integer) n1 - (Integer) n2));

		

	}

}
