package org.nfjs.jpractice.core.lambda;

import java.util.Arrays;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Predicate;

public class LambdaStarter {

	public static void main(String[] args) {
		List<Integer> numbers = Arrays.asList(1, 2, 3);
		// traditional way;
		System.out.println("traditional:");
		for (Integer i : numbers) {
			System.out.print(i + "\t");
		}
		System.out.print("\n" + "using functional interface:\n");
		numbers.forEach(new Consumer<Integer>() {
			public void accept(Integer value) {
				System.out.print(value + "\t");
			}

		});
		System.out.print("\n" + "using lambda expression:\n");
		numbers.forEach((Integer i) -> {
			System.out.print(i + "\t");
		});
		System.out.print("\n" + "using lambda expression - concise way:\n");
		numbers.forEach(value -> System.out.print(value + "\t"));
		System.out.print("\n" + "using lambda expression - even more concise way:\n");
		numbers.forEach(System.out::print);

		// sum all numbers:
		System.out.println("\n" + sumAll(numbers, n -> n % 2 == 0));
		System.out.println("\n" + sumAll(numbers, n -> true));
		System.out.println("\n" + sumAll(numbers, n -> n > 1));
	}

	public static int sumAll(List<Integer> numbers, Predicate<Integer> p) {
		int total = 0;
		/*
		 * for (int number : numbers) { if (p.test(number)) { total += number; }
		 * }
		 */
		total = numbers.stream().map(n -> {
			return p.test(n) ? n : 0;
		}).reduce((x, y) -> x + y).get();
		return total;
	}

}
