package org.nfjs.jpractice.core.lambda;

import java.util.Arrays;
import java.util.List;

public class LambdaNine {

	public static void main(String[] args) {
		List<Integer> numbers = Arrays.asList(4, 5, 7, 8, 10, 12);
		System.out.println(numbers.stream().map(n -> {
			return (n % 2 == 0) ? n : 0;
		}).reduce((x, y) -> {
			return x + y;
		}).get());
	}

}
