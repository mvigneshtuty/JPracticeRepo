package org.nfjs.jpractice.core.instrumentation;

public class InboundMessage {
	private int messageId;
	private String messageContent;

	public int getMessageId() {
		return messageId;
	}

	public void setMessageId(int messageId) {
		this.messageId = messageId;
	}

	public String getMessageContent() {
		return messageContent;
	}

	public void setMessageContent(String messageContent) {
		this.messageContent = messageContent;
	}

	public String displayInfo() {
		return getMessageContent();
	}
}
