package org.nfjs.jpractice.core.instrumentation;

public class MessageInstrumentationMain {

	public static void main(String[] args) {
		InboundMessage im = new InboundMessage();
		System.out.println(im.displayInfo());

	}

}
