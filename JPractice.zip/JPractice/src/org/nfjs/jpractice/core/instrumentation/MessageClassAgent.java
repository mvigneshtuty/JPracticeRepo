package org.nfjs.jpractice.core.instrumentation;

import java.lang.instrument.Instrumentation;

public class MessageClassAgent {
	public static void premain(String agentArgs, Instrumentation inst) {
		inst.addTransformer(new MessageClassTransformer());
	}
}
