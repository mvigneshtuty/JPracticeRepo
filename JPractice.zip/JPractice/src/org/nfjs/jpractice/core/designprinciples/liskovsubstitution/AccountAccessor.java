package org.nfjs.jpractice.core.designprinciples.liskovsubstitution;

public class AccountAccessor {
	AccountType account;

	AccountAccessor(AccountType accountType) {
		this.account = accountType;
	}

	public static void main(String... strings) {
		depositInSavings(new SavingsAccount());
		depositInCurrent(new CurrentAccount());
	}

	private static void depositInSavings(SavingsAccount savingsAccount) {
		AccountAccessor accountAccessor = new AccountAccessor(savingsAccount);
		try {
			accountAccessor.account.deposit(1000);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private static void depositInCurrent(CurrentAccount currentAccount) {
		AccountAccessor accountAccessor = new AccountAccessor(currentAccount);
		try {
			accountAccessor.account.deposit(500);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
