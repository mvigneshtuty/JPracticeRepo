package org.nfjs.jpractice.core.designprinciples.liskovsubstitution;

public class CurrentAccount extends AccountType {

	@Override
	void deposit(int amount) {
		System.out.println("Amount " + amount + " deposited successfuly to current account");

	}

}
