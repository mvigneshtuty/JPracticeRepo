package org.nfjs.jpractice.core.designprinciples.liskovsubstitution;

public class SavingsAccount extends AccountType {

	@Override
	void deposit(int amount) throws NullPointerException{
		System.out.println("Amount " + amount + " deposited successfuly to savings account");

	}

}
