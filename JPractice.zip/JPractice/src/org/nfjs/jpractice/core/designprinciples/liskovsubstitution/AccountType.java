package org.nfjs.jpractice.core.designprinciples.liskovsubstitution;

public abstract class AccountType {
	abstract void deposit(int amount) throws Exception;
}
