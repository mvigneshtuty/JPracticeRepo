package org.nfjs.jpractice.core.immutable;

public class Discount {
	private final int totalAmount;
	private final int discountPercent;

	private Discount(int totalAmount, int discountPercent) {
		this.totalAmount = totalAmount;
		this.discountPercent = discountPercent;
	}

	public static Discount valueOf(int totalAmount, int discountPercent) {
		return new Discount(totalAmount, discountPercent);
	}

	public int getAmount() {
		return totalAmount;
	}

	public static Discount apply(Discount d) {
		return new Discount((d.getAmount() - (d.getAmount() * d.discountPercent / 100)), d.discountPercent);
	}
}
