package org.nfjs.jpractice.core.immutable;

public class DiscountTest {
	public static void main(String... strings) {
		Discount discount = Discount.valueOf(100, 5);
		int effectiveTotal = Discount.apply(discount).getAmount();
		System.out.println(effectiveTotal);
	}
}
