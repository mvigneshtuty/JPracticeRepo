package org.nfjs.jpractice.core.objects;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class WsMessage {

	private static final WsMessage messageInstance = new WsMessage();

	private WsMessage() {

	}

	private void getPayload(String requestor) {
		System.out.println("getting payload of " + requestor);
	}
	
	private static WsMessage getInstance(){
		return messageInstance;
	}
	
	public static void main(String...strings){
		WsMessage message1 = WsMessage.getInstance();
		message1.getPayload("message One ");
		WsMessage message2 = WsMessage.getInstance();
		message2.getPayload("message Two ");
		Map<String, List<String>> m = WsMessage.newInstance();
		Map<String, Object> m2 = WsMessage.newInstance();
		
	}
	
	public static <K, V> HashMap<K, V> newInstance() {
		return new HashMap<K, V>();
		}
}
