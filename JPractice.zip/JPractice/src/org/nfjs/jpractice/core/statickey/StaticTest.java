package org.nfjs.jpractice.core.statickey;

public class StaticTest {

	public static void main(String[] args) {
		StaticTest s = null;
		s.invoke(); 
	}

	public static void invoke(){
		System.out.println("static method invocation");
	}
}
