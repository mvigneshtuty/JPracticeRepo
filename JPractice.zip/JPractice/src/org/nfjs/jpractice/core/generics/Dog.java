package org.nfjs.jpractice.core.generics;

public class Dog extends Animal {

	private boolean isMammal;

	public boolean isMammal() {
		return isMammal;
	}

	public void setMammal(boolean isMammal) {
		this.isMammal = isMammal;
	}

}
