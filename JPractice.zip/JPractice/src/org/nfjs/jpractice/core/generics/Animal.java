package org.nfjs.jpractice.core.generics;

public class Animal {
	private String name;
	private String family;

	Animal(){
		
	}
	Animal(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getFamily() {
		return family;
	}

	public void setFamily(String family) {
		this.family = family;
	}
}
