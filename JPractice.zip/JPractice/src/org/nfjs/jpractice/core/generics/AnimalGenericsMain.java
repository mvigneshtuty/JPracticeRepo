package org.nfjs.jpractice.core.generics;

import java.util.ArrayList;
import java.util.List;

public class AnimalGenericsMain {

	public static void main(String[] args) {
		Animal a1 = new Animal();
		Animal a2 = new Animal();
		List<Animal> animals = new ArrayList<Animal>() {
			{
				add(new Animal("Crocodile"));
				add(new Animal("Monkey"));
			}
		};
		Dog d1 = new Dog();
		Dog d2 = new Dog();
		Dog d3 = new Dog();
		List<Dog> dogs = new ArrayList<Dog>();
		dogs.add(d1);
		dogs.add(d2);
		dogs.add(d3);
		addAnimalsToCollections(animals);

	}

	public static void addAnimalsToCollections(List<? extends Animal> input) {
		List<Animal> gList = new ArrayList<>();
		input.forEach(p -> gList.add(p));
		System.out.println(gList.size());
	}

}
