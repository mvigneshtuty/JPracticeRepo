package org.nfjs.jpractice.core.generics;

import org.junit.Test;

public class AutoBoxing {
	
	@Test
	public void primitiveNullPointer() {
		
		final Integer intObject = 42;
		assert (intObject == 42);
		try {
			final int newIntValue = methodWhichMayReturnNull(intObject);
			//fail("Assignment of null to primitive should throw NPE");
		} catch (NullPointerException e) {
			// do nothing, test passed
			e.printStackTrace();
		}
	}

	private Integer methodWhichMayReturnNull(Integer intValue) {
		return null;
	}

}
