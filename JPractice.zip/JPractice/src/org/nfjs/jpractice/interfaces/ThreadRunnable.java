package org.nfjs.jpractice.interfaces;

public interface ThreadRunnable extends Runnable {
	
}
