package org.nfjs.jpractice.interfaces;

@FunctionalInterface
public interface CustomLambdaInterface {

	void printArgs(String s);
}
