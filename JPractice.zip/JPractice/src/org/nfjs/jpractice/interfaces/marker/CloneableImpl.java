package org.nfjs.jpractice.interfaces.marker;

public class CloneableImpl implements Cloneable {

}
