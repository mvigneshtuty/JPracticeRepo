/**
 * 
 */
package org.nfjs.jpractice.interfaces;

/**
 * @author 353453
 *
 */

/*
 * Following declaration will throw compile error
 * 
 * public interface CyclicInterface extends CyclicInterface { int doCalc(); }
 */

public interface CyclicInterface {
	int doCalc();
	default int getResult(){
		return 56;
	}
	
	static int getAverage(){
		return 99;
	}
	
	public void calcExpense();
}
