package org.nfjs.jpractice.interfaces;

import java.awt.event.ActionListener;

public interface LambdaButtonListener extends ActionListener {
	void actionPerformed();
}
