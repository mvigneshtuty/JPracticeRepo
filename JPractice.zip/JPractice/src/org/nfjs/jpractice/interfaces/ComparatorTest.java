package org.nfjs.jpractice.interfaces;

import java.util.Comparator;

import org.nfjs.jpractice.main.StudentsGroup;

public class ComparatorTest {
	public static void main(String... strings) {
		StudentsGroup sg = new StudentsGroup(); 
	}
}
